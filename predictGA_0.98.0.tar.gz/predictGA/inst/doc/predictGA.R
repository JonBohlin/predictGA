## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----predictGA-----------------------------------------------------------
require(predictGA)
cpgs=extractSites(type="se")
allcpgs=extractSites(type="all")
numsamples=100
mlmatr=matrix(NA, ncol=length(allcpgs), nrow=numsamples)
mlmatr=data.frame(mlmatr)
for(i in cpgs)
  mlmatr[,i]=runif(numsamples, min=0, max=1)

## ----predictGA2----------------------------------------------------------
mypred=predictGA(mlmatr)
head(mypred)

## ----extractSites--------------------------------------------------------
cpgs=extractSites(type="se")
cpgs[1:10]

